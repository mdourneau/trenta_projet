<?php

namespace AxomeGitCommits;

class GitHub {

    private $username;

    private $repository;

    private $branch;

    private $client;

    public function __construct($username, $repository, $branch)
    {
        $this->username = $username;
        $this->repository = $repository;
        $this->branch = $branch;

        $this->client = new \Github\Client();
    }

    public function checkGitHubData(): bool
    {
        $res = $this->getAllCommits();
        if(!is_array($res)) {
            return false;
        }
        return true;
    }

    public function getAllCommits(): ?array
    {
        return $this->client->api('repo')->commits()->all($this->username, $this->repository, ['sha' => $this->branch]);
    }
}